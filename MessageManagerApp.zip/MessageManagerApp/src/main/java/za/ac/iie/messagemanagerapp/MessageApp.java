
package za.ac.iie.messagemanagerapp;

import java.util.Scanner;

public class MessageApp {

    static Scanner input = new Scanner(System.in);

    // Arrays for storing messages
    static Message[] sentMessages = new Message[100];
    static Message[] storedMessages = new Message[100];
    static Message[] discardedMessages = new Message[100];

    static int sentCount = 0;
    static int storedCount = 0;
    static int discardedCount = 0;

    public static void main(String[] args) {

        // Sample messages for testing
        storedMessages[storedCount++] =
            new Message("MSG001", "John", "27812345678",
            "Hello, how are you?");

        storedMessages[storedCount++] =
            new Message("MSG002", "Mary", "27823456789",
            "Where are you? I have been waiting for you.");

        storedMessages[storedCount++] =
            new Message("MSG003", "Peter", "27812345678",
            "Thank you for your help.");

        int choice;

        do {
            System.out.println("\n===== MESSAGE MANAGEMENT SYSTEM =====");
            System.out.println("1. Add a sent message");
            System.out.println("2. Store a message");
            System.out.println("3. Display sender and recipient");
            System.out.println("4. Display longest stored message");
            System.out.println("5. Search using Message ID");
            System.out.println("6. Search messages by recipient");
            System.out.println("7. Delete message using Message Hash");
            System.out.println("8. Display message report");
            System.out.println("9. Exit");

            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1:
                    addSentMessage();
                    break;

                case 2:
                    addStoredMessage();
                    break;

                case 3:
                    displaySenderRecipient();
                    break;

                case 4:
                    displayLongestMessage();
                    break;

                case 5:
                    searchMessageID();
                    break;

                case 6:
                    searchRecipient();
                    break;

                case 7:
                    deleteMessage();
                    break;

                case 8:
                    displayReport();
                    break;

                case 9:
                    System.out.println("Thank you for using the system!");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 9);
    }

    // Add a sent message
    public static void addSentMessage() {

        if (sentCount >= sentMessages.length) {
            System.out.println("Sent messages are full.");
            return;
        }

        System.out.print("Enter Message ID: ");
        String id = input.nextLine();

        System.out.print("Enter sender: ");
        String sender = input.nextLine();

        System.out.print("Enter recipient: ");
        String recipient = input.nextLine();

        System.out.print("Enter message: ");
        String message = input.nextLine();

        sentMessages[sentCount++] =
            new Message(id, sender, recipient, message);

        System.out.println("Message sent successfully.");
    }

    // Store a message
    public static void addStoredMessage() {

        if (storedCount >= storedMessages.length) {
            System.out.println("Stored messages are full.");
            return;
        }

        System.out.print("Enter Message ID: ");
        String id = input.nextLine();

        System.out.print("Enter sender: ");
        String sender = input.nextLine();

        System.out.print("Enter recipient: ");
        String recipient = input.nextLine();

        System.out.print("Enter message: ");
        String message = input.nextLine();

        storedMessages[storedCount++] =
            new Message(id, sender, recipient, message);

        System.out.println("Message stored successfully.");
    }

    // Display sender and recipient
    public static void displaySenderRecipient() {

        if (storedCount == 0) {
            System.out.println("No stored messages.");
            return;
        }

        for (int i = 0; i < storedCount; i++) {

            System.out.println("Sender: "
                + storedMessages[i].getSender());

            System.out.println("Recipient: "
                + storedMessages[i].getRecipient());

            System.out.println("--------------------");
        }
    }

    // Display longest message
    public static void displayLongestMessage() {

        if (storedCount == 0) {
            System.out.println("No stored messages.");
            return;
        }

        Message longest = storedMessages[0];

        for (int i = 1; i < storedCount; i++) {

            if (storedMessages[i].getMessageText().length()
                    > longest.getMessageText().length()) {

                longest = storedMessages[i];
            }
        }

        System.out.println("Longest stored message:");
        longest.displayMessage();
    }

    // Search using Message ID
    public static void searchMessageID() {

        System.out.print("Enter Message ID: ");
        String id = input.nextLine();

        boolean found = false;

        for (int i = 0; i < storedCount; i++) {

            if (storedMessages[i].getMessageID().equalsIgnoreCase(id)) {

                storedMessages[i].displayMessage();
                found = true;
            }
        }

        if (!found) {
            System.out.println("Message not found.");
        }
    }

    // Search messages by recipient
    public static void searchRecipient() {

        System.out.print("Enter recipient number: ");
        String recipient = input.nextLine();

        boolean found = false;

        for (int i = 0; i < storedCount; i++) {

            if (storedMessages[i].getRecipient()
                    .equalsIgnoreCase(recipient)) {

                storedMessages[i].displayMessage();
                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    // Delete message using Message Hash
    public static void deleteMessage() {

        System.out.print("Enter Message Hash: ");
        String hash = input.nextLine();

        boolean found = false;

        for (int i = 0; i < storedCount; i++) {

            if (storedMessages[i].getMessageHash().equalsIgnoreCase(hash)) {

                discardedMessages[discardedCount++] = storedMessages[i];

                for (int j = i; j < storedCount - 1; j++) {
                    storedMessages[j] = storedMessages[j + 1];
                }

                storedMessages[storedCount - 1] = null;
                storedCount--;

                System.out.println("Message deleted successfully.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Message hash not found.");
        }
    }

    // Display message report
    public static void displayReport() {

        System.out.println("\n===== MESSAGE REPORT =====");

        System.out.println("Sent Messages: " + sentCount);
        System.out.println("Stored Messages: " + storedCount);
        System.out.println("Discarded Messages: " + discardedCount);

        System.out.println("\nSTORED MESSAGE DETAILS:");

        for (int i = 0; i < storedCount; i++) {
            storedMessages[i].displayMessage();
        }

        System.out.println("===== END OF REPORT =====");
    }
}
