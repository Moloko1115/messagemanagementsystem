package za.ac.iie.messagemanagerapp;

public class Message {

    private String messageID;
    private String sender;
    private String recipient;
    private String messageText;
    private String messageHash;

    public Message(String messageID, String sender,
                   String recipient, String messageText) {

        this.messageID = messageID;
        this.sender = sender;
        this.recipient = recipient;
        this.messageText = messageText;

        this.messageHash = Integer.toHexString(
            (messageID + sender + recipient + messageText).hashCode()
        );
    }

    public String getMessageID() {
        return messageID;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public void displayMessage() {
        System.out.println("Message ID: " + messageID);
        System.out.println("Sender: " + sender);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + messageText);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("--------------------------------");
    }
}
