
package za.ac.iie.messagemanagerapp;

import java.util.Scanner;

public class MessageManagementSystem {

    static Scanner input = new Scanner(System.in);

    static Message[] storedMessages = new Message[100];
    static Message[] sentMessages = new Message[100];
    static Message[] discardedMessages = new Message[100];

    static int storedCount = 0;
    static int sentCount = 0;
    static int discardedCount = 0;

    public static void main(String[] args) {

        int choice;

        do {
            System.out.println("\n===== MESSAGE MANAGEMENT SYSTEM =====");
            System.out.println("1. Add a sent message");
            System.out.println("2. Store a message");
            System.out.println("3. Display sender and recipient");
            System.out.println("4. Display longest stored message");
            System.out.println("5. Search using Message ID");
            System.out.println("6. Search messages by recipient");
            System.out.println("7. Delete message using Message Hash");
            System.out.println("8. Display message report");
            System.out.println("9. Exit");

            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1:
                    addMessage();
                    break;
                case 2:
                    storeMessage();
                    break;
                case 3:
                    displaySenderRecipient();
                    break;
                case 4:
                    displayLongestMessage();
                    break;
                case 5:
                    searchMessage();
                    break;
                case 6:
                    searchRecipient();
                    break;
                case 7:
                    deleteMessage();
                    break;
                case 8:
                    displayReport();
                    break;
                case 9:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 9);
    }

    public static void addMessage() {

        if (sentCount >= sentMessages.length) {
            System.out.println("Sent messages are full.");
            return;
        }

        System.out.print("Enter Message ID: ");
        String id = input.nextLine();

        System.out.print("Enter sender: ");
        String sender = input.nextLine();

        System.out.print("Enter recipient: ");
        String recipient = input.nextLine();

        System.out.print("Enter message: ");
        String message = input.nextLine();

        sentMessages[sentCount++] =
            new Message(id, sender, recipient, message);

        System.out.println("Message sent successfully.");
    }

    public static void storeMessage() {

        if (storedCount >= storedMessages.length) {
            System.out.println("Stored messages are full.");
            return;
        }

        System.out.print("Enter Message ID: ");
        String id = input.nextLine();

        System.out.print("Enter sender: ");
        String sender = input.nextLine();

        System.out.print("Enter recipient: ");
        String recipient = input.nextLine();

        System.out.print("Enter message: ");
        String message = input.nextLine();

        storedMessages[storedCount++] =
            new Message(id, sender, recipient, message);

        System.out.println("Message stored successfully.");
    }

    public static void displaySenderRecipient() {

        for (int i = 0; i < storedCount; i++) {
            System.out.println("Sender: "
                + storedMessages[i].getSender());

            System.out.println("Recipient: "
                + storedMessages[i].getRecipient());
        }
    }

    public static void displayLongestMessage() {

        if (storedCount == 0) {
            System.out.println("No stored messages.");
            return;
        }

        Message longest = storedMessages[0];

        for (int i = 1; i < storedCount; i++) {
            if (storedMessages[i].getMessageText().length()
                    > longest.getMessageText().length()) {
                longest = storedMessages[i];
            }
        }

        longest.displayMessage();
    }

    public static void searchMessage() {

        System.out.print("Enter Message ID: ");
        String id = input.nextLine();

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getMessageID().equalsIgnoreCase(id)) {
                storedMessages[i].displayMessage();
                return;
            }
        }

        System.out.println("Message not found.");
    }

    public static void searchRecipient() {

        System.out.print("Enter recipient: ");
        String recipient = input.nextLine();

        boolean found = false;

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getRecipient()
                    .equalsIgnoreCase(recipient)) {
                storedMessages[i].displayMessage();
                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found.");
        }
    }

    public static void deleteMessage() {

        System.out.print("Enter Message Hash: ");
        String hash = input.nextLine();

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getMessageHash()
                    .equalsIgnoreCase(hash)) {

                if (discardedCount < discardedMessages.length) {
                    discardedMessages[discardedCount++] =
                        storedMessages[i];
                }

                for (int j = i; j < storedCount - 1; j++) {
                    storedMessages[j] = storedMessages[j + 1];
                }

                storedMessages[--storedCount] = null;

                System.out.println("Message deleted.");
                return;
            }
        }

        System.out.println("Message hash not found.");
    }

    public static void displayReport() {

        System.out.println("\n===== MESSAGE REPORT =====");
        System.out.println("Sent messages: " + sentCount);
        System.out.println("Stored messages: " + storedCount);
        System.out.println("Discarded messages: " + discardedCount);

        for (int i = 0; i < storedCount; i++) {
            storedMessages[i].displayMessage();
        }
    }
}
